<?php
/**
 * Plugin Name:       AI Suite SEO Pro
 * Plugin URI:        https://example.com/aisuite/seo-pro
 * Description:       Adds site-wide bulk optimization, scheduled re-analysis, and auto-apply rules to AI Suite SEO.
 * Version:           0.1.0
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  aisuite-core, aisuite-seo
 * Author:            Your Company
 * License:           GPL-2.0-or-later
 * Text Domain:       aisuite-seo-pro
 *
 * NOT distributed on WordPress.org. Ships from your own store with its own
 * update server. The free plugin must never contain locked code that this one
 * unlocks — that is what gets a plugin pulled from the directory.
 */

defined( 'ABSPATH' ) || exit;

define( 'AISUITE_SEO_PRO_VERSION', '0.1.0' );
define( 'AISUITE_SEO_PRO_FILE', __FILE__ );

require_once plugin_dir_path( __FILE__ ) . 'includes/class-updater.php';

add_action(
	'plugins_loaded',
	function () {
		if ( ! function_exists( 'aisuite' ) || ! class_exists( 'AISuite_SEO_Optimizer' ) ) {
			return;
		}

		new AISuite_SEO_Pro_Updater( AISUITE_SEO_PRO_FILE, AISUITE_SEO_PRO_VERSION );
		new AISuite_SEO_Pro();
	},
	20
);

register_deactivation_hook(
	__FILE__,
	function () {
		wp_clear_scheduled_hook( AISuite_SEO_Pro::CRON_HOOK );
	}
);

class AISuite_SEO_Pro {

	const OPTION      = 'aisuite_seo_pro_settings';
	const CRON_HOOK   = 'aisuite_seo_pro_sweep';
	const BATCH_SIZE  = 25;

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ), 30 );
		add_action( 'admin_post_aisuite_seo_pro_save', array( $this, 'save' ) );
		add_action( 'admin_post_aisuite_seo_pro_bulk', array( $this, 'run_bulk' ) );
		add_action( self::CRON_HOOK, array( $this, 'sweep' ) );
		add_action( 'aisuite_job_completed_seo.analyze_post', array( $this, 'maybe_auto_apply' ), 20, 2 );

		if ( ! wp_next_scheduled( self::CRON_HOOK ) && $this->settings()['schedule_enabled'] ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	public function settings() {
		return wp_parse_args(
			(array) get_option( self::OPTION, array() ),
			array(
				'schedule_enabled'  => false,
				'auto_apply_empty'  => false,
				'daily_post_limit'  => 50,
			)
		);
	}

	public function menu() {
		add_submenu_page(
			'aisuite',
			__( 'SEO Pro', 'aisuite-seo-pro' ),
			__( 'SEO Pro', 'aisuite-seo-pro' ),
			'manage_options',
			'aisuite-seo-pro',
			array( $this, 'render' )
		);
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this.', 'aisuite-seo-pro' ) );
		}

		$settings = $this->settings();
		?>
		<div class="wrap aisuite-wrap">
			<h1><?php esc_html_e( 'SEO Pro', 'aisuite-seo-pro' ); ?></h1>

			<div class="aisuite-panel">
				<h2><?php esc_html_e( 'Automation', 'aisuite-seo-pro' ); ?></h2>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'aisuite_seo_pro_save' ); ?>
					<input type="hidden" name="action" value="aisuite_seo_pro_save" />

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Daily sweep', 'aisuite-seo-pro' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="schedule_enabled" value="1" <?php checked( $settings['schedule_enabled'] ); ?> />
									<?php esc_html_e( 'Re-analyze posts changed since their last analysis, once a day.', 'aisuite-seo-pro' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Auto-apply', 'aisuite-seo-pro' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="auto_apply_empty" value="1" <?php checked( $settings['auto_apply_empty'] ); ?> />
									<?php esc_html_e( 'Apply titles and descriptions automatically when the field is currently empty.', 'aisuite-seo-pro' ); ?>
								</label>
								<p class="description">
									<?php esc_html_e( 'Only fills gaps. Anything that would overwrite existing text still goes to the review queue.', 'aisuite-seo-pro' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="aisuite-limit"><?php esc_html_e( 'Daily post limit', 'aisuite-seo-pro' ); ?></label></th>
							<td>
								<input type="number" id="aisuite-limit" name="daily_post_limit" min="1" max="500" value="<?php echo esc_attr( $settings['daily_post_limit'] ); ?>" />
								<p class="description"><?php esc_html_e( 'Caps how many actions the sweep can spend per day.', 'aisuite-seo-pro' ); ?></p>
							</td>
						</tr>
					</table>

					<?php submit_button( __( 'Save settings', 'aisuite-seo-pro' ) ); ?>
				</form>
			</div>

			<div class="aisuite-panel">
				<h2><?php esc_html_e( 'Bulk run', 'aisuite-seo-pro' ); ?></h2>
				<p><?php esc_html_e( 'Queues every published post and page that has never been analyzed.', 'aisuite-seo-pro' ); ?></p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'aisuite_seo_pro_bulk' ); ?>
					<input type="hidden" name="action" value="aisuite_seo_pro_bulk" />
					<?php submit_button( __( 'Start bulk run', 'aisuite-seo-pro' ), 'primary', 'submit', false ); ?>
				</form>
			</div>
		</div>
		<?php
	}

	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'aisuite-seo-pro' ) );
		}

		check_admin_referer( 'aisuite_seo_pro_save' );

		$settings = array(
			'schedule_enabled' => ! empty( $_POST['schedule_enabled'] ),
			'auto_apply_empty' => ! empty( $_POST['auto_apply_empty'] ),
			'daily_post_limit' => isset( $_POST['daily_post_limit'] ) ? min( 500, max( 1, (int) $_POST['daily_post_limit'] ) ) : 50,
		);

		update_option( self::OPTION, $settings, false );

		if ( $settings['schedule_enabled'] && ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		} elseif ( ! $settings['schedule_enabled'] ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=aisuite-seo-pro' ) );
		exit;
	}

	public function run_bulk() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'aisuite-seo-pro' ) );
		}

		check_admin_referer( 'aisuite_seo_pro_bulk' );

		$this->queue_batch( self::BATCH_SIZE, true );

		wp_safe_redirect( admin_url( 'admin.php?page=aisuite-seo' ) );
		exit;
	}

	public function sweep() {
		$this->queue_batch( $this->settings()['daily_post_limit'], false );
	}

	/**
	 * @param int  $limit      Max posts to queue.
	 * @param bool $never_only Only posts with no prior analysis.
	 */
	protected function queue_batch( $limit, $never_only ) {
		$meta_query = $never_only
			? array(
				array(
					'key'     => '_aisuite_seo_analyzed',
					'compare' => 'NOT EXISTS',
				),
			)
			: array();

		$post_ids = get_posts(
			array(
				'post_type'      => array( 'post', 'page' ),
				'post_status'    => 'publish',
				'posts_per_page' => (int) $limit,
				'fields'         => 'ids',
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'meta_query'     => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			)
		);

		$optimizer = new AISuite_SEO_Optimizer();
		$enforce   = (bool) get_current_user_id(); // Cron sweeps run with no user.

		foreach ( $post_ids as $post_id ) {
			$result = $optimizer->analyze( $post_id, $enforce );

			// Queue full or out of credits: stop rather than hammer the gateway
			// once per post for the rest of the batch.
			if ( is_wp_error( $result ) && in_array( $result->get_error_code(), array( 'aisuite_queue_full', 'aisuite_out_of_credits', 'aisuite_not_connected' ), true ) ) {
				break;
			}
		}
	}

	/**
	 * Auto-apply gap fills only. Never overwrites something a human wrote.
	 */
	public function maybe_auto_apply( $result, $context ) {
		if ( ! $this->settings()['auto_apply_empty'] ) {
			return;
		}

		$post_id = isset( $context['post_id'] ) ? (int) $context['post_id'] : 0;

		if ( ! $post_id ) {
			return;
		}

		$optimizer   = new AISuite_SEO_Optimizer();
		$suggestions = AISuite_SEO_Store::query(
			array(
				'status'   => 'pending',
				'post_id'  => $post_id,
				'per_page' => 10,
			)
		);

		foreach ( $suggestions as $row ) {
			if ( ! in_array( $row->field, array( 'title', 'description' ), true ) ) {
				continue;
			}

			if ( '' !== trim( (string) $row->current_value ) ) {
				continue;
			}

			// Runs inside the gateway callback, where there is no current user.
			// The site owner authorized this by enabling auto-apply.
			$optimizer->apply( $row->id, false );
		}
	}
}
